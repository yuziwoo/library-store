window.addEventListener("DOMContentLoaded", (e) => {
  //
});
